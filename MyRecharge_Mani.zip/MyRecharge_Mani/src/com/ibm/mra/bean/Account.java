package com.ibm.mra.bean;

public class Account {
	private String accountType;
	private String customerName;
	private Double accountBalance;
	
	//Constructor
	public Account(String accountType,String customerName,Double accountBalance){
		this.accountType = accountType;
		this.customerName=customerName;
		this.accountBalance=accountBalance;
		
		
	}
	
	
	
	//Getter and Setter Methods();
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String toString() {
		return "Account [account type " + accountType + " Customer name is :" + customerName +" Account Balance is: " + accountBalance + "]";
	}
	
}
