package com.ibm.mra.service;

import com.ibm.mra.bean.Account;
import com.ibm.mra.dao.AccountDao;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceimpl implements AccountService {
	AccountDaoImpl dao = new AccountDaoImpl();
	public Account getAccountDetails(String mobileNo) {
		return null;
		
	}
	public int rechargeAccount(String mobileNo,double rechargeAmount) {
		return 0;
		
	}
	public boolean validateAccount(String mobileno) {
		return dao.validateAccount(mobileno);
		
	}
	

}
