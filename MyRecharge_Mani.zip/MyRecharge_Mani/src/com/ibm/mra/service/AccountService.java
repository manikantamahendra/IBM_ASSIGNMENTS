package com.ibm.mra.service;

import com.ibm.mra.bean.Account;

public interface AccountService {
	
	public Account getAccountDetails(String mobileNo);
	public int rechargeAccount(String mobileNo,double rechargeAmount);
	public boolean validateAccount(String mobileno);
	
	
	

}
