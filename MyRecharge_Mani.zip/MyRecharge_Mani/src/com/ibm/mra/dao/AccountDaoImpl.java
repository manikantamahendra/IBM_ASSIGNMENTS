package com.ibm.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.mra.bean.Account;


public class AccountDaoImpl {
	
	private Map<String,Account> account;
	public AccountDaoImpl() {
		account = new HashMap<>();
		account.put("9666569133", new Account("Prepaid","manikanta",100.00));
		account.put("9182963363", new Account("Prepaid","mahendra",200.00));
		account.put("9030707213", new Account("Prepaid","Rambabu",300.00));
		account.put("9652196472", new Account("Prepaid","sandeep",400.00));
		
	}
	
	public boolean validateAccount(String mobileno) {
		for ( String key : account.keySet() ) {
			if(mobileno.equals(key)) {
				
				return true;
			}
		    
		}return false;
		
	}

	//public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
	//	for ( String key : account.keySet() ) {
		//	if(mobileNo.equals(key)) {
			//	return Account.getAccountBalance();
			//}
	
	
	
		
	}	
		
	
	

