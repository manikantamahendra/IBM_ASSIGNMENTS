package com.ibm.mra.dao;

import com.ibm.mra.bean.Account;

public interface AccountDao {
	public boolean validateAccount(String mobileNo);
	public Account getAccountDetails(String mobileNo);
		


}
