package com.ibm.mra.ui;

import java.util.Scanner;

import com.ibm.mra.bean.Account;

import com.ibm.mra.service.AccountServiceimpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int exit=0;
		int choice;
		Account account = null;
		Scanner sc = new Scanner(System.in);
		AccountServiceimpl service = new AccountServiceimpl();
		while(exit == 0)
		{
			System.out.println("Enter choice of operation you want to perform");
			System.out.println("1.Account Balance Enquiry \n"
					          + "2.Recharge Amount \n"
					          + "3.Exit");
			try
			{
				choice = sc.nextInt();
				sc.nextLine();
				switch(choice) {
				
				case 1:{
					System.out.println("Enter your Mobile Number :");
					String mobile_num = sc.nextLine();
					if(service.validateAccount(mobile_num)) {
						System.out.println(" Account balance is  :" +service.getAccountDetails(mobile_num));
						
						
						
					}else {
						System.out.println("No such data exists");
					}
						
					}
				case 2:
					System.out.println("Enter Mobile Number");
					String Mobile_num= sc.nextLine();
					
					System.out.println("Enter Balance :");
					Double bal = sc.nextDouble();
						
					
				}
					
				
				}catch(Exception e) {
					System.out.println("no valid");
				}
		
	}

	}
}


