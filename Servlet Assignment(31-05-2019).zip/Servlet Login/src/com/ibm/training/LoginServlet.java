package com.ibm.training;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	Connection con;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm", "root", "");
			PreparedStatement stmt = con.prepareStatement("select * from login");
			ResultSet rs = stmt.executeQuery();

			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			String usr = request.getParameter("userName");
			String pass = request.getParameter("userpass");
			while (rs.next()) {
				if (usr.equals(rs.getString(1)) && pass.equals(rs.getString(2))) {
					RequestDispatcher dispatcher = request.getRequestDispatcher("/success");
					dispatcher.forward(request, response);
					

				}
			}

			if (usr.trim() == "" && pass == "") {
				out.println("You can't leave the username and password empty!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");

				dispatcher.include(request, response);
			}
			else {
						out.println("Incorrect user or password");
						response.setContentType("text/html");
						RequestDispatcher dispatcher = request.getRequestDispatcher("/index.html");
						dispatcher.include(request, response);
					}
				}
	catch(ClassNotFoundException|SQLException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();

	}

}}
